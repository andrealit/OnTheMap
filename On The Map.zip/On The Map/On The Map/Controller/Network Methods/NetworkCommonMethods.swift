//
//  NetworkCommonMethods.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/2/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import Foundation

extension NetworkLayer{
    
    // create URL from params
    public static func onTheMapURLFromParameters(_ parameters: [String:AnyObject], withPathExtension: String? = nil) -> URL {
        var components = URLComponents()
        components.scheme = Constants.ApiScheme
        components.host = Constants.ApiHost
        components.path = Constants.ApiPath + (withPathExtension ?? "")
        components.queryItems = [URLQueryItem]()
        
        for (key, value) in parameters{
            components.queryItems?.append(URLQueryItem(name: key, value: "\(value)"))
        }
        
        return components.url!
    }
}
