//
//  MapConvenience.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/3/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import MapKit

// This extension reads in data and makes it more convenient for the user to view location data.
extension MapViewController{
    func getMapLocationAnnotation(for student: Student) -> MKPointAnnotation{
        // Converts lat & long into CLLocationDegrees.
        let lat = CLLocationDegrees(student.latitude!)
        let long = CLLocationDegrees(student.longitude!)
        
        // The lat and long create a coordinate
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
        
        // Annotation and set properties
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "\(student.firstName!) \(student.lastName!)"
        annotation.subtitle = student.mediaURL!
        
        // return the annotation point
        return annotation
    }
}
