//
//  MapViewController.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/2/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import Foundation
import MapKit

class MapViewController: UIViewController {
    // MARK: Properties
    // holds only valid students for showing up their data
    var students = [Student] ()
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(reloadStarted), name: .reloadStarted, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(reloadCompleted), name: .reloadCompleted, object: nil)
        reloadCompleted()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func reloadStarted() {
        startAnimation()
    }
    
    @objc func reloadCompleted() {
        self.students = [Student] ()
        startAnimation()
        for student in StudentsLocations.shared.students {
            let(success, _) = student.isValid(for: .displayingLocation)
            if success {
                // add student into students list
                self.students.append(student)
                DispatchQueue.main.async {
                    self.mapView.addAnnotation(self.getMapLocationAnnotation(for: student))
                }
            }
        }
        stopAnimation()
    }
    
    private func startAnimation() {
        DispatchQueue.main.async {
            self.activityIndicator.isHidden = false
            self.activityIndicator.startAnimating()
        }
    }
    
    private func stopAnimation() {
        DispatchQueue.main.async {
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        }
    }
}
