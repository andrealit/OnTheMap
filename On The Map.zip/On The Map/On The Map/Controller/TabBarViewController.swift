//
//  TabBarViewController.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/2/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadStudentsLocations()
    }
    
    @IBAction func logout(_ sender: Any) {
        NetworkLayer.deleteCurrentStudentSession() {
            (success, data, error) in
            if success {
                DispatchQueue.main.async {
                    self.dismiss(animated: true, completion: nil)
                }
            } else {
                self.notify(title: .error, body: error?.userInfo.values.description ?? "Error while logging out.", return: .dismiss)
            }
        }
    }
    
    @IBAction func reload(_ sender: Any) {
        self.loadStudentsLocations()
    }
    
    @objc func loadStudentsLocations(){
        NotificationCenter.default.post(name: .reloadStarted, object: nil)
        NetworkLayer.getStudentLocations()  { (success, allStudents, error) in
            if success, let allStudents = allStudents {
                StudentsLocations.shared.students = allStudents
            } else {
                self.notify(title: .sorry, body: error?.userInfo.values.description ?? "Error while loading other student locations", return: .dismiss)
            }
            NotificationCenter.default.post(name: .reloadCompleted, object: nil)
        }
    }
    
    private func notify(title: ErrorDisplay.NotifyMessageHeader, body: String, return returnType: ErrorDisplay.NotifyMessageReturnType){
        let alert = ErrorDisplay.notify(title: title, body: body, return: returnType)
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
}
