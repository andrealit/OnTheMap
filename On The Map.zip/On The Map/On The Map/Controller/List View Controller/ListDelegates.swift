//
//  ListDelegates.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/3/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import Foundation
import UIKit

extension ListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.students.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let student = self.students[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath)
        cell.textLabel?.text = student.fullName()
        cell.detailTextLabel?.text = student.mediaURL!
        cell.imageView?.image = UIImage(named: "icon_pin")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let student = self.students[indexPath.row]
        let app = UIApplication.shared
        if let url = URL(string: student.mediaURL!) {
            app.open(url, options: [:], completionHandler: nil)
        }
    }
}
