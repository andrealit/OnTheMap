//
//  AddLocationViewController.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/3/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class AddLocationViewController: UIViewController {
    // MARK: Outlets
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var mediaURL: UITextField!
    @IBOutlet weak var findLocation: UIButton!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.topItem?.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancel))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        startAnimation()
        super.viewWillAppear(animated)
        self.location.text = ""
        self.mediaURL.text = ""
        stopAnimation()
    }
    
    @objc func cancel() {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func findLocation(_ sender: Any) {
        guard location?.text != nil, location?.text != String() else {
            notify(title: .sorry, body: "Empty location is not allowed!", return: .dismiss)
            return
        }
        guard mediaURL?.text != nil, mediaURL?.text != String() else {
            notify(title: .error, body: "Empty media url is not allowed!", return: .dismiss)
            return
        }
        
        self.getLocationFromAddress() { (success, error, location) in
            if success {
                let confirmLocationVC = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmLocationViewController") as! ConfirmLocationViewController
                confirmLocationVC.location = location
                confirmLocationVC.address = self.location.text!
                confirmLocationVC.mediaURL = self.mediaURL.text!
                DispatchQueue.main.async {
                    self.navigationController?.pushViewController(confirmLocationVC, animated: true)
                }
            } else {
                DispatchQueue.main.async {
                    self.notify(title: .sorry, body: error!, return: .dismiss)
                }
            }
        }
    }
    
    private func getLocationFromAddress(completionHandler: @escaping(_ success: Bool, _ error: String?, _ location: CLLocation?) -> Void) {
        startAnimation()
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString((location?.text!)!) { (placemarks, error) in
            self.stopAnimation()
            guard let placemarks = placemarks, let location = placemarks.first?.location else {
                completionHandler(false, "Location you have entered is not recognized.", nil)
                return
            }
            completionHandler(true, nil, location)
        }
    }
    
    private func notify(title: ErrorDisplay.NotifyMessageHeader, body: String, return returnType: ErrorDisplay.NotifyMessageReturnType) {
        let alert = ErrorDisplay.notify(title: title, body: body, return: returnType)
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    private func startAnimation() {
        enableUI(isEnabled: false)
    }
    
    private func stopAnimation() {
        enableUI(isEnabled: true)
    }
    
    private func enableUI(isEnabled: Bool) {
        DispatchQueue.main.async {
            self.activityIndicator.isHidden = isEnabled
            
            if !isEnabled {
                self.activityIndicator.startAnimating()
            } else {
                self.activityIndicator.stopAnimating()
            }
            
            self.location.isEnabled = isEnabled
            self.mediaURL.isEnabled = isEnabled
            self.findLocation.isEnabled = isEnabled
        }
    }
}
