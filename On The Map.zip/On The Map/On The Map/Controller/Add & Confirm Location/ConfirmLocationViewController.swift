//
//  ConfirmLocationViewController.swift
//  On The Map
//
//  Created by Andrea Tongsak on 7/2/19.
//  Copyright © 2019 Andrea Tongsak. All rights reserved.
//

import Foundation
import MapKit

class ConfirmLocationViewController: UIViewController {
    // MARK: Properties
    var address: String?
    var location: CLLocation?
    var mediaURL: String?
    
    // MARK: Outlet
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        startAnimation()
        let annotation = MKPointAnnotation()
        annotation.coordinate = self.location!.coordinate
        annotation.title = self.address!
        annotation.subtitle = self.mediaURL!
        self.mapView.addAnnotation(annotation)
        let region = MKCoordinateRegion(center: annotation.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        self.mapView.setRegion(region, animated: true)
        stopAnimation()
    }
    
    @IBAction func finish(_ sender: Any) {
        startAnimation()
        let student = Student(objectId: nil, uniqueKey: nil, firstName: nil, lastName: nil, mapString: self.address, mediaURL: self.mediaURL, latitude: self.location?.coordinate.latitude, longitude: self.location?.coordinate.longitude)
        NetworkLayer.postLocation(for: student) { (success, error) in
            self.stopAnimation()
            if success {
                self.notify(title: .success, body: "Location is added.", return: .ok, {
                    self.dismiss(animated: true, completion: nil)
                })
            } else {
                self.notify(title: .sorry, body: error?.userInfo.values.description ?? "Unexpected error!", return: .dismiss, {
                    self.navigationController?.popToRootViewController(animated: true)
                })
            }
        }
    }
    
    private func notify(title: ErrorDisplay.NotifyMessageHeader, body: String, return returnType: ErrorDisplay.NotifyMessageReturnType, _ firstHandler:(() -> Void)? = nil, _ secondHandler:(() -> Void)? = nil) {
        DispatchQueue.main.async {
            let alert = ErrorDisplay.notify(title: title, body: body, return: returnType, {firstHandler?()}, {secondHandler?()})
            
            self.present(alert, animated: true)
        }
    }
    
    private func startAnimation() {
        DispatchQueue.main.async {
            self.activityIndicator.isHidden = false
            self.activityIndicator.startAnimating()
        }
    }
    
    private func stopAnimation() {
        DispatchQueue.main.async {
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        }
    }
    
}
// MARK: - MKMapViewDelegate
extension ConfirmLocationViewController: MKMapViewDelegate{
        
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            
        let reuseId = "pin"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
            
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
            
            return pinView
        }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if control == view.rightCalloutAccessoryView {
            let app = UIApplication.shared
            if let toOpen = view.annotation?.subtitle! {
                app.open(URL(string: toOpen)!, options: [:], completionHandler: nil)
            }
        }
    }
}
